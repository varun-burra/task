# Project-Management-System
Project Management System in PHP is a platform from which employees and managers can use for collaboration and communication.

Prerequisite:
For using this project you have to create a database using 'pms_project.sql' file.

User can perform the following operations:
- Add new user
    : a unique User ID will be created autamatically
- Allocate task to particular user
    : a unique Task ID will be created autamatically
    : default status will be 'In progress'
- Manage Task
    : Change the task
    : Change status
    : Delete the task
- Delete User
- Sending us feedback
