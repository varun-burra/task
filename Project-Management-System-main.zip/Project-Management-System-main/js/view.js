document.getElementById("back-btn").addEventListener("click", () => {
  history.back();
  history.back();
});
