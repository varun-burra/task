<?php
    $con = mysqli_connect("localhost", "root", "2507", "cms_project");
    if(!$con) {
        die("not connected");
    }
?>