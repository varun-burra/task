    <!-- navbar -->
    <nav id="navbar">
      <div class="nameOfProject">CMS System</div>
      <ul>
        <li><button id="homePageBtn">Home</button></li>
        <li><button id="createPageBtn">Create</button></li>
        <li><button id="profilePageBtn">Profile</button></li>
      </ul>
    </nav>