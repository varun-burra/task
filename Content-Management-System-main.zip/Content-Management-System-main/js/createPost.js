// const months = [
//   'January',
//   'February',
//   'March',
//   'April',
//   'May',
//   'June',
//   'July',
//   'August',
//   'September',
//   'October',
//   'November',
//   'December',
// ];
// const date = new Date();
// let year = date.getFullYear();
// let month = formatData(date.getMonth() + 1);
// let day = formatData(date.getDate());
// let hour = formatData(date.getHours());
// let mins = formatData(date.getMinutes());
// let secs = formatData(date.getSeconds());
// let ms = formatMillisecond(date.getMilliseconds());

// let time = hour + ":" + mins;
// document.cookie = 'cms_currentTime='+time;

// let monthName = months[date.getMonth()];

// function formatData(num) {
//   return num < 10 ? '0' + num : num + '';
// }

// function formatMillisecond(num) {
//   if (num < 10) return '00' + num;
//   if (num < 100) return '0' + num;
//   return num + '';
// }

// let PID = 'PID' + year + month + day + hour + mins + secs + ms;
// document.cookie = 'cms_create_PID='+PID;
// console.log(PID);
// console.log(postDate);
// console.log(working);

